package by.belhard.j24.MyFirstProject.exceptions;

public class WrongInputException extends RuntimeException {
}
