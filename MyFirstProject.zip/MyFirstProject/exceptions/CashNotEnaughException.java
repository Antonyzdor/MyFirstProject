package by.belhard.j24.MyFirstProject.exceptions;

public class CashNotEnaughException extends RuntimeException {
}

