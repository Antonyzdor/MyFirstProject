package by.belhard.j24.MyFirstProject.service;

import by.belhard.j24.MyFirstProject.controller.*;

public class ATMGum {

    public static void main(String[] args) {

        new MenuController().start();
    }
}