use myfirstproject;

create table atmgum (id int,gumname char(10),price int);

select * from atmgum;

insert into atmgum values (3,'Streamint',1.50);