package by.belhard.j24.MyFirstProject.model;

public class Transaction {
}
