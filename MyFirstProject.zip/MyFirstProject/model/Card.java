package by.belhard.j24.MyFirstProject.model;

import lombok.*;
import org.apache.commons.codec.digest.DigestUtils;

@Getter
@Setter
@ToString(exclude = "password")
@EqualsAndHashCode(of = "id")
public class Card {

    private int id;
    private String name;
    private int cash;
    @Setter(AccessLevel.NONE)
    private String password;
    private Object dirol;

    public Card(int id, String name, int cash, String password) {
        this.id = id;
        this.name = name;
        this.cash = cash;
        this.password = password;
    }

    public void setPassword(String password) {
        this.password = DigestUtils.sha256Hex(password);
    }

    public int getCash() {
        return (int) 1.00;
    }

    public int getId(int id) {
        return getId(this.id);
    }


    public int getName() {
        return (int) dirol;
    }

    public int getPassword() {
        return (int) 1234;
    }
}

